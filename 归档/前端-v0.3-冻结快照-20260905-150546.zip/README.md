# 知应 AI · 前端工作空间

当前工程版本 v0.3.0。基于总体技术设计 v1.3 和前端功能模块，在原有星球首页、7 个客服模块、预览身份页及功能规划页上，新增工作空间概览与全局快捷搜索，统一深色界面、表单和响应式布局。页面交互采用内存示例数据，未连接真实 AI。总体开发文档保持 v1.3。

## 查看页面

启动本地服务后，打开 [工作空间概览](http://127.0.0.1:5173/#/overview)。根地址默认进入管理员概览；内部使用者进入对话页。概览提供会话统计、有效回复数、示例消费、待处理任务、可切换费用／Token 的调用图、预算余量和配置状态，均读取现有内存状态。

可直接打开的独立入口是 [public/space.html](E:/ai-customer-service-plan/开发/frontend/public/space.html)：双击可打开星球首页，不需要安装或构建。HTML 内含页面 CSS 与 JavaScript，视频、图片、字体通过网络加载。本轮保留其星球切换与媒体逻辑。

工作台是 Vue 工程，需要运行本地服务。在直接打开 HTML 的模式下，“开始对话”和模块链接指向本机 5173 端口；通过 HTTP 访问时链接使用当前站点。

## 本地运行

要求 Node.js 24.12.0 或更高，pnpm 11.19.0；v0.3 验证使用 Node.js 24.18.0。TypeScript 固定为 5.9.3，与当前 vue-tsc 一起完成类型检查。

在 PowerShell 中执行：

    Set-Location -LiteralPath 'E:\ai-customer-service-plan\开发\frontend'
    pnpm install --frozen-lockfile
    pnpm dev

打开 [工作空间概览](http://127.0.0.1:5173/#/overview)、[对话工作台](http://127.0.0.1:5173/#/chat) 或 [星球首页](http://127.0.0.1:5173/space.html)。服务仅监听本机。端口占用时不会自动跳到其他端口。

点击顶栏搜索或按 Ctrl / ⌘ + K 可搜索页面与当前身份的会话；↑ / ↓ 选择、Enter 打开、Esc 关闭。概览的场景卡片会创建新会话并预填草稿，仍由用户点击发送。手机导航支持键盘焦点约束、Esc 关闭及返回触发按钮。

本机若 pnpm 不在 PATH，可使用已安装的运行时：

    $env:PATH = 'C:\Users\15375\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin;' + $env:PATH
    & 'C:\Users\15375\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe' 'C:\Users\15375\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\node_modules\pnpm\bin\pnpm.cjs' dev

此备用路径只适用于当前电脑，其他电脑使用自己的 Node.js／pnpm 安装。

## 构建与验证

    pnpm build
    pnpm test
    pnpm test:e2e

- build：先执行 vue-tsc 类型检查，再打包；输出 dist/index.html、dist/space.html 及静态资源。
- test：16 项必要状态检查，包含重复提交、停止、重试、预算、导出删除及连接测试竞态。
- test:e2e：22 项 Playwright 浏览器流程，包含原有 17 项及新增的概览统计联动、图表切换、场景草稿、快捷搜索、身份过滤、配置状态、手机焦点与布局。临时启动 5174 端口，测试结束后停止。Windows 使用本机 Edge；其他系统可安装 Playwright Chromium。
- 浏览器回归报告：playwright-report/index.html、test-results/results.json。首页自动化流程使用替代媒体以避免 CDN 波动；真实素材不是靠替代媒体测试认定成功。
- node scripts/capture-preview.cjs：在 5173 开发服务已运行时检查实际网络素材，生成截图和媒体／DOM 切换记录到审计目录。此脚本不调用真实 AI。
- node scripts/capture-workspace.cjs：在本地服务运行后，采集 10 个工作空间页面的桌面／手机截图与快捷导航截图，记录页面错误与溢出结果到审计/前端-v0.3-证据。可通过 PREVIEW_URL 指定构建预览地址。

构建产物需要 HTTP 服务承载工作台；可执行 pnpm preview，在 4173 端口查看。仅星球首页 HTML 可独立以文件方式运行。未在公网部署。

## 目录

| 位置 | 职责 |
| --- | --- |
| public/space.html | 无框架单文件星球首页 |
| src/views | 7 个模块及身份／规划页面 |
| src/views/OverviewView.vue | 管理员概览、调用图、预算、状态与场景入口 |
| src/components/CommandPalette.vue | 原生弹窗快捷搜索、键盘选择与身份过滤 |
| src/data/navigation.ts | 导航元数据及共享场景提示词 |
| src/components | 图标、标题、空状态、弹窗 |
| src/stores/workspace.ts | 示例状态及交互边界 |
| src/domain/rules.ts | 重试资格、示例金额和字符估算 |
| src/data/fixtures.ts | 不含真实客户信息的初始样例 |
| src/styles.css、view-styles.css、space-theme.css、workspace-ui.css | 基础结构、页面布局、深空基础主题及 v0.3 界面与响应式样式 |
| src/stores/workspace.test.ts、tests | 状态、原有浏览器流程及 overview.spec.ts 新交互回归 |
| scripts/capture-preview.cjs | 实际网络素材及截图复验 |

## 功能与后端接入

完整页面、身份和阶段映射见[前端功能模块](E:/ai-customer-service-plan/产品/前端功能模块.md)。

真实接入时在页面与后端间增加 API／事件适配层，以服务端的认证、状态和账本为准，不把当前内存 store 当成授权服务、持久数据库或实际计费系统。浏览器不得持有供应商主密钥，不要把 Key 写入 VITE_* 环境变量或前端源码。当前 Key 输入禁用，连接测试仅演示状态变化。

刷新会重置本次会话、额度修改和身份；离开聊天页会取消当前示例回复。费用样例与简单字符 Token 估算仅用于交互，不代表供应商报价或真实防超支能力。保存对话不等于授权用于训练。

## 首页设计来源与改编

采用用户提供的星球视频、海报和透明切图 URL，以及指定的 Prata／Hanken Grotesk／Poppins 字体、--u 比例构图、六档响应规则和一次性入场动画。保留双侧固定图片槽、三颗星球可逆切换、静帧降级及 .22s 背景过渡。

改编内容：SpaceEdu 品牌及教育导航改为“知应 AI”客服内容；导航胶囊加宽以容纳中文；下箭头打开功能弹窗；非地球主按钮打开演进蓝图；增加暂停背景、示例说明和可用页面链接。遵循提示词后面的入场要求，head 有一个短初始化脚本，body 尾部有一个主脚本；不存在外部 JavaScript 依赖。

媒体 URL 和字体由外部站点提供，不能承诺离线可用或永久可访问。减少动画模式显示静帧，视频故障保留海报；全部外部媒体失败时仍可操作文字与导航。实际浏览器绘制／网络延迟与同步 DOM 切换耗时分别看待。

## 验证记录

v0.2 的历史记录见[前端整改复验报告 v0.2](E:/ai-customer-service-plan/审计/前端整改复验报告-v0.2.md)。v0.3 的新增范围、验证结果及截图见[前端页面开发验收记录 v0.3](E:/ai-customer-service-plan/审计/前端页面开发验收记录-v0.3.md)。这些结论不替代真实系统的 V1 验收。
