<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import PageHeading from '../components/PageHeading.vue'
import AppIcon from '../components/AppIcon.vue'
import AppModal from '../components/AppModal.vue'
import { workspace } from '../stores/workspace'
const { state } = workspace
const name = ref(state.workspaceName)
const confirmPause = ref(false)
const router = useRouter()
function save() { if (state.role === 'admin' && name.value.trim()) { state.workspaceName = name.value.trim(); workspace.notify('工作空间名称已更新，仅保留在本页') } }
function switchMember() { workspace.setRole('member'); void router.push('/chat') }
</script>
<template>
  <PageHeading title="工作空间设置" subtitle="管理当前工作空间与演示服务状态。" eyebrow="WORKSPACE SETTINGS" />
  <div class="two-column-layout"><div class="stack">
    <section class="card"><div class="card-header"><h2>基本信息</h2><span class="badge">内部工作空间</span></div><form class="card-body" @submit.prevent="save"><label class="form-field"><span>工作空间名称</span><input v-model="name" class="input" maxlength="30" required /></label><div class="form-actions"><button class="button primary" type="submit">保存名称</button></div></form></section>
    <section class="card"><div class="card-header"><h2>自动回复</h2><span class="badge" :class="state.serviceEnabled ? 'green' : 'orange'">{{ state.serviceEnabled ? '演示已开启' : '演示已暂停' }}</span></div><div class="card-body"><p class="muted">暂停后，当前页面的生成会停止，新消息将被拦截。待核对预留仍保留。</p><div class="form-actions"><button v-if="state.serviceEnabled" class="button danger" @click="confirmPause = true"><AppIcon name="ban" :size="14" />暂停演示自动回复</button><button v-else class="button primary" @click="workspace.setService(true)">恢复演示自动回复</button></div></div></section>
    <section class="card"><div class="card-header"><h2>身份预览</h2><AppIcon name="shield" /></div><div class="card-body"><p class="muted">管理员可查看所有管理模块；内部使用者只查看自己名下的示例会话。身份切换用于界面体验，不构成真实权限隔离。</p><div class="form-actions"><button class="button" @click="switchMember">体验内部使用者</button><RouterLink class="button" to="/login">进入身份选择页</RouterLink></div></div></section>
  </div><div class="stack"><section class="card"><div class="card-header"><h2>当前环境</h2><AppIcon name="layers" /></div><div class="card-body"><dl class="detail-list"><div><dt>版本</dt><dd>v0.3 · 前端预览</dd></div><div><dt>数据</dt><dd>浏览器页面内存</dd></div><div><dt>真实模型</dt><dd>未接入</dd></div><div><dt>访客客服</dt><dd>V2 待开发</dd></div><div><dt>知识库</dt><dd>V2 待开发</dd></div></dl></div></section><div class="note"><AppIcon name="lock" :size="16" /><span>不要输入真实密钥或客户信息。刷新会恢复初始样例；安全认证、数据持久化与服务端停机开关尚未实现。</span></div><a class="button" href="/space.html"><AppIcon name="external" :size="14" />返回星球首页</a></div></div>
  <AppModal :open="confirmPause" title="暂停演示自动回复？" description="暂停当前页面中的回复生成。已有示例会话与待核对预留仍保留。" @close="confirmPause = false"><div class="form-actions"><button class="button" @click="confirmPause = false">取消</button><button class="button danger" @click="workspace.setService(false); confirmPause = false">确认暂停</button></div></AppModal>
</template>

