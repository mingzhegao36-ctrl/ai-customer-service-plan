<script setup lang="ts">
import { useRouter } from 'vue-router'
import { workspace } from '../stores/workspace'
import AppIcon from '../components/AppIcon.vue'
import type { Role } from '../types'
const router = useRouter()
function enter(role: Role) { workspace.setRole(role); void router.push(role === 'admin' ? '/overview' : '/chat') }
</script>
<template>
  <div class="login-page"><a class="login-home" href="/space.html">知应 <span>AI SUPPORT</span></a><div class="login-art"><span class="login-orbit"></span><span class="login-orbit second"></span><div class="login-planet"></div><p>EVERY CONVERSATION<br />IS A NEW WORLD.</p></div><section class="login-panel"><span class="eyebrow">YOUR NEXT ORBIT</span><h1>进入你的<br />客服工作空间。</h1><p class="muted">选择预览身份，体验页面与功能模块。<br />真实登录尚未接入。</p><button class="identity-choice" @click="enter('admin')"><span class="tag-icon"><AppIcon name="shield" :size="24" /></span><span><strong>管理员</strong><small>聊天、配置、预算与任务管理</small></span><AppIcon name="arrow" /></button><button class="identity-choice" @click="enter('member')"><span class="tag-icon"><AppIcon name="chat" :size="24" /></span><span><strong>内部使用者</strong><small>个人对话与会话记录</small></span><AppIcon name="arrow" /></button><div class="note neutral"><AppIcon name="lock" :size="16" /><span>仅使用示例数据，不收集密码或 API Key。刷新页面会重置预览。</span></div><a class="login-back" href="/space.html">← 返回星球首页</a></section></div>
</template>
