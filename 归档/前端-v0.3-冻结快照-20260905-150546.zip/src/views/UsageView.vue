<script setup lang="ts">
import { computed, ref } from 'vue'
import PageHeading from '../components/PageHeading.vue'
import AppIcon from '../components/AppIcon.vue'
import { workspace } from '../stores/workspace'
import { money } from '../domain/rules'
const { state, usageTotals, availableCents } = workspace
const daily = ref(state.dailyLimitCents / 100)
const monthly = ref(state.monthlyLimitCents / 100)
const filter = ref('all')
const entries = computed(() => state.usage.filter(u => filter.value === 'all' || u.status === filter.value))
const percent = computed(() => Math.min(100, (usageTotals.value.spent + usageTotals.value.held) / state.dailyLimitCents * 100))
const labels = { actual: '已确认 · 示例', unknown: '待核对', running: '进行中' }
</script>
<template>
  <PageHeading title="用量与预算" subtitle="把消费、预留与剩余额度放在一起看。" eyebrow="USAGE & BUDGET"><span class="badge">本地示例账本</span></PageHeading>
  <div class="stat-grid">
    <section class="card stat-card"><div class="stat-label">已确认消费<AppIcon name="chart" /></div><div class="stat-value">{{ money(usageTotals.spent) }}</div><p class="stat-caption">演示金额，无真实扣费</p></section>
    <section class="card stat-card"><div class="stat-label">待核对与进行中预留<AppIcon name="clock" /></div><div class="stat-value">{{ money(usageTotals.held) }}</div><p class="stat-caption">中断后保留，避免提前释放额度</p></section>
    <section class="card stat-card"><div class="stat-label">可用额度<AppIcon name="shield" /></div><div class="stat-value text-green">{{ money(availableCents) }}</div><p class="stat-caption">取日／月限制中较小值后扣减</p></section>
    <section class="card stat-card"><div class="stat-label">记录 Token<AppIcon name="layers" /></div><div class="stat-value">{{ usageTotals.tokens.toLocaleString() }}</div><p class="stat-caption">含固定样例及本地字符估算</p></section>
  </div>
  <div class="two-column-layout">
    <section class="card table-card"><div class="card-header"><div><h2>调用明细</h2><p>示例账本随本页聊天交互更新</p></div><select v-model="filter" class="filter-select" aria-label="费用状态"><option value="all">全部状态</option><option value="actual">已确认</option><option value="unknown">待核对</option><option value="running">进行中</option></select></div>
      <div class="table-wrap"><table><thead><tr><th>调用记录</th><th>Token</th><th>消费／预留</th><th>状态</th></tr></thead><tbody><tr v-for="entry in entries" :key="entry.id"><td><strong class="ledger-title">{{ entry.label }}</strong><small class="block muted">{{ entry.time }}</small></td><td class="tabular">{{ entry.tokens.toLocaleString() }}</td><td class="tabular">{{ money(entry.status === 'actual' ? entry.costCents : entry.heldCents) }}</td><td><span class="badge" :class="entry.status === 'actual' ? 'green' : 'orange'">{{ labels[entry.status] }}</span></td></tr><tr v-if="!entries.length"><td colspan="4">该状态下暂无记录。</td></tr></tbody></table></div>
      <div class="table-footer">全部记录为当前页面示例；金额不代表供应商报价。</div>
    </section>
    <div class="stack"><section class="card"><div class="card-header"><h2>预算控制</h2><AppIcon name="sliders" /></div><form class="card-body" @submit.prevent="workspace.saveBudget(Number(daily), Number(monthly))"><div class="metric-line"><span>演示日额度占用</span><strong>{{ percent.toFixed(1) }}%</strong></div><div class="progress-track budget-track"><div class="progress-fill" :style="{ width: percent + '%' }"></div></div><label class="form-field"><span>每日上限（元）</span><input v-model="daily" aria-label="每日上限（元）" class="input" type="number" min="0.01" max="1000000" step="0.01" required /></label><label class="form-field"><span>每月上限（元）</span><input v-model="monthly" aria-label="每月上限（元）" class="input" type="number" min="0.01" max="1000000" step="0.01" required /></label><button class="button primary full" type="submit">保存演示额度</button></form></section><div class="note"><AppIcon name="shield" :size="16" /><span>正式预算需服务端原子预留、对账与计费周期。这里仅演示页面状态，不具备实际防超支能力。</span></div></div>
  </div>
</template>

