<script setup lang="ts">
import { onBeforeUnmount, reactive, ref } from 'vue'
import AppIcon from '../components/AppIcon.vue'
import PageHeading from '../components/PageHeading.vue'
import { workspace } from '../stores/workspace'
import type { ConnectionTestTicket } from '../types'
const { state } = workspace
const form = reactive({ name: state.connection.name, baseUrl: state.connection.baseUrl, model: state.connection.model })
const testing = ref(false)
let pending: ConnectionTestTicket | undefined
let testTimer: ReturnType<typeof setTimeout> | undefined
function simulateTest() {
  if (!workspace.saveConnection(form)) return
  const ticket = workspace.beginConnectionTest()
  if (!ticket) return
  pending = ticket
  testing.value = true
  testTimer = setTimeout(() => {
    workspace.completeConnectionTest(ticket)
    testing.value = false
    pending = undefined
  }, 550)
}
onBeforeUnmount(() => { clearTimeout(testTimer); if (pending) workspace.cancelConnectionTest(pending) })
</script>
<template>
  <PageHeading title="模型连接" subtitle="连接模型的入口，也为每一次调用建立清楚的边界。" eyebrow="MODEL CONNECTION"><span class="badge orange">V1 · 单供应商</span></PageHeading>
  <div class="two-column-layout"><section class="card"><div class="card-header"><div><h2>供应商连接</h2><p>当前为示例配置，不发送真实网络请求</p></div><span class="badge" :class="{ green: state.connection.tested }"><span class="status-dot"></span>{{ state.connection.tested ? '模拟可用' : '待模拟测试' }}</span></div><form class="card-body" @submit.prevent="workspace.saveConnection(form)"><label class="form-field"><span>连接名称</span><input v-model="form.name" class="input" maxlength="50" required placeholder="例如：内部客服模型" /></label><label class="form-field"><span>API 地址</span><input v-model="form.baseUrl" class="input code" type="url" required maxlength="250" placeholder="https://api.example.com/v1" /><small>仅用于配置交互演示，不会向该地址提交消息。</small></label><label class="form-field"><span>模型标识</span><input v-model="form.model" class="input code" required maxlength="100" placeholder="demo-support-model" /></label><label class="form-field"><span>API Key <span class="inline-muted">后端接入后启用</span></span><div class="disabled-secret"><AppIcon name="lock" :size="16" /><input class="input" type="password" readonly disabled aria-label="API Key 尚未启用" placeholder="当前预览不接收真实密钥" /></div><small>正式凭据由服务端安全保存，聊天用户不接触 Key。</small></label><div class="form-actions"><button type="button" class="button" :disabled="testing" @click="simulateTest"><AppIcon :name="testing ? 'loading' : 'plug'" :size="14" :class="{ spinning: testing }" />{{ testing ? '模拟测试中…' : '模拟连接测试' }}</button><button class="button primary" type="submit"><AppIcon name="check" :size="14" />保存示例配置</button></div></form></section>
    <aside class="stack"><section class="card"><div class="card-header"><h2>当前连接概览</h2><AppIcon name="plug" :size="17" /></div><div class="card-body"><div class="connection-logo"><AppIcon name="sparkle" :size="26" /><span><strong>{{ state.connection.name }}</strong><small>DEMO CONNECTION</small></span></div><div class="divider"></div><div class="detail-list"><div><span>模型</span><strong class="model-id">{{ state.connection.model }}</strong></div><div><span>使用助手</span><strong>{{ state.assistantName }}</strong></div><div><span>实际请求</span><strong>尚未接入</strong></div><div><span>真实凭据</span><strong>未收集</strong></div></div></div></section><div class="note"><AppIcon name="shield" :size="16" /><span>模拟测试只改变页面状态。供应商权限、模型能力和真实费用需要后续服务端联调验证。</span></div></aside></div>
</template>
