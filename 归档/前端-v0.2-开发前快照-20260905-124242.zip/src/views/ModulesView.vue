<script setup lang="ts">
import PageHeading from '../components/PageHeading.vue'
import AppIcon from '../components/AppIcon.vue'
import { workspace } from '../stores/workspace'
const modules = [
{ number: '01', icon: 'chat', title: '对话工作台', description: '发送、停止、末轮重试与反馈。', path: '/chat', role: '所有体验身份' },
{ number: '02', icon: 'history', title: '会话记录', description: '搜索、筛选、打开、移除与示例导出。', path: '/history', role: '个人会话；管理员导出' },
{ number: '03', icon: 'bot', title: '助手配置', description: '提示词草稿、版本启用与停用。', path: '/assistant', role: '管理员' },
{ number: '04', icon: 'plug', title: '模型连接', description: '连接信息编辑与模拟测试。', path: '/connections', role: '管理员' },
{ number: '05', icon: 'chart', title: '用量与预算', description: '示例消费、待核对预留与额度。', path: '/usage', role: '管理员' },
{ number: '06', icon: 'tasks', title: '任务中心', description: '示例任务追踪、详情与下载。', path: '/tasks', role: '管理员' },
{ number: '07', icon: 'settings', title: '工作空间设置', description: '空间名称、演示身份与暂停回复。', path: '/settings', role: '管理员' },
]
</script>
<template>
  <PageHeading title="功能模块与演进" subtitle="先做好内部对话，再逐步扩展为智能客服。" eyebrow="EXPLORE THE WORKSPACE"><a class="button" href="/space.html">返回星球首页<AppIcon name="external" :size="14" /></a></PageHeading>
  <div class="module-intro card"><div><span class="badge green">当前 · 前端交互预览</span><h2>一个工作空间，七个核心模块。</h2><p>“知应”是本次预览暂用名称。以下模块基于既有 V1 产品范围，使用本地示例数据。V2 / V3 / V4 仅展示规划。</p></div><AppIcon name="layers" :size="72" :stroke=".8" /></div>
  <div class="module-grid"><section v-for="(item, index) in modules" :key="item.path" class="card module-card"><div class="flex-row space-between"><span class="tag-icon"><AppIcon :name="item.icon" :size="22" /></span><span class="module-number">{{ item.number }}</span></div><h2>{{ item.title }}</h2><p>{{ item.description }}</p><div class="module-card-footer"><span>{{ item.role }}</span><RouterLink v-if="workspace.state.role === 'admin' || index < 2" :to="item.path" :aria-label="'进入' + item.title"><AppIcon name="arrow" :size="17" /></RouterLink><AppIcon v-else name="lock" :size="14" /></div></section></div>
  <div class="roadmap-band"><div><span>V2</span><h3>知识与客服</h3><p>知识库检索、引用、审核、访客与人工接管。</p></div><div><span>V3</span><h3>业务工具</h3><p>订单查询等受控工具及调用授权。</p></div><div><span>V4</span><h3>训练与微调</h3><p>数据授权、清洗、训练集、评测与灰度。</p></div></div>
  <div class="note"><AppIcon name="alert" :size="16" /><span>前端演示通过不代表产品验收通过。真实认证、模型接口、持久化、服务端预算及异步任务协议均待接入。反馈等 Should 功能的预览不会改变原需求优先级。</span></div>
</template>

