<script setup lang="ts">
import { computed, ref, watch, onMounted, onUnmounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { workspace } from './stores/workspace'
import AppIcon from './components/AppIcon.vue'
const route = useRoute()
const router = useRouter()
const { state } = workspace
const mobileNav = ref(false)
const profileOpen = ref(false)
const navigation = [
  { path: '/chat', title: '对话工作台', icon: 'chat' },
  { path: '/history', title: '会话记录', icon: 'history' },
  { path: '/assistant', title: '助手配置', icon: 'bot', admin: true },
  { path: '/connections', title: '模型连接', icon: 'plug', admin: true },
  { path: '/usage', title: '用量与预算', icon: 'chart', admin: true },
  { path: '/tasks', title: '任务中心', icon: 'tasks', admin: true },
  { path: '/settings', title: '工作空间设置', icon: 'settings', admin: true },
]
const navItems = computed(() => navigation.filter(n => !n.admin || state.role === 'admin'))
const isLogin = computed(() => route.path === '/login')
watch(() => route.path, () => { mobileNav.value = false; profileOpen.value = false })
function logout() { workspace.setRole(null); void router.push('/login') }
function pageHidden() { workspace.stop('failed', '页面已离开，演示回复已停止') }
async function shortcut(event: KeyboardEvent) { if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k' && state.role) { event.preventDefault(); await router.push('/chat'); requestAnimationFrame(() => document.getElementById('chat-input')?.focus()) } }
onMounted(() => { window.addEventListener('pagehide', pageHidden); window.addEventListener('keydown', shortcut) })
onUnmounted(() => { window.removeEventListener('pagehide', pageHidden); window.removeEventListener('keydown', shortcut) })
</script>
<template>
  <a class="skip-link" href="#main-content">跳到主要内容</a>
  <div v-if="!isLogin" class="workspace-shell">
    <button v-if="mobileNav" class="nav-backdrop" aria-label="关闭导航" @click="mobileNav = false"></button>
    <aside class="sidebar" :class="{ 'is-open': mobileNav }" aria-label="工作空间导航">
      <RouterLink class="brand" to="/chat"><img src="/mark.svg" alt="" /><span>知应<span class="brand-en">AI SUPPORT</span></span></RouterLink>
      <div class="workspace-label"><span class="workspace-monogram">W</span><span>{{ state.workspaceName }}<small>内部工作空间</small></span></div>
      <div class="nav-section-label">工作台</div>
      <nav class="nav-items"><RouterLink v-for="item in navItems" :key="item.path" :to="item.path" class="nav-item"><AppIcon :name="item.icon" /><span>{{ item.title }}</span><span v-if="item.path === '/chat'" class="nav-shortcut">Ctrl K</span></RouterLink></nav>
      <div class="nav-section-label future-label">下一阶段</div>
      <RouterLink class="future-nav" to="/modules"><AppIcon name="book" /><span>知识库</span><small>V2</small></RouterLink>
      <RouterLink class="future-nav" to="/modules"><AppIcon name="headset" /><span>人工客服</span><small>V2</small></RouterLink>
      <RouterLink class="future-nav" to="/modules"><AppIcon name="flask" /><span>训练与评测</span><small>V4</small></RouterLink>
      <div class="sidebar-bottom">
        <div class="growth-card"><span class="tiny-icon"><AppIcon name="layers" :size="17" /></span><strong>从对话，走向智能客服</strong><p>先做好每一次回应，再逐步接入知识与业务。</p><RouterLink to="/modules">查看功能规划 <AppIcon name="external" :size="14" /></RouterLink></div>
        <div class="profile-wrap"><button class="profile-button" :aria-expanded="profileOpen" @click="profileOpen = !profileOpen"><span class="avatar small">{{ state.role === 'admin' ? 'A' : 'M' }}</span><span>{{ state.role === 'admin' ? '示例管理员' : '示例内部使用者' }}<small>前端体验身份</small></span><AppIcon name="more" /></button>
          <div v-if="profileOpen" class="profile-menu"><RouterLink to="/login"><AppIcon name="sliders" :size="16" />切换预览身份</RouterLink><button @click="logout"><AppIcon name="logout" :size="16" />退出演示</button></div>
        </div>
      </div>
    </aside>
    <div class="main-shell">
      <header class="topbar"><div class="breadcrumb"><button class="icon-button mobile-menu" aria-label="打开导航" :aria-expanded="mobileNav" @click="mobileNav = true"><AppIcon name="menu" /></button><span class="breadcrumb-root">工作空间</span><AppIcon name="chevron" :size="14" /><span>{{ route.meta.title }}</span></div><div class="topbar-actions"><span class="preview-tag"><span class="status-dot"></span>前端预览<span class="desktop-only"> · 示例数据</span></span><RouterLink class="icon-button help-link" to="/modules" aria-label="查看功能模块与预览说明"><AppIcon name="help" :size="20" /></RouterLink><span class="avatar top-avatar">{{ state.role === 'admin' ? 'A' : 'M' }}</span></div></header>
      <main id="main-content" tabindex="-1" class="main-content"><RouterView /></main>
    </div>
  </div>
  <main v-else id="main-content"><RouterView /></main>
  <Transition name="toast"><div v-if="state.toast" class="toast-message" role="status"><AppIcon name="success" :size="18" /><span>{{ state.toast }}</span><button class="icon-button" aria-label="关闭提示" @click="state.toast = ''"><AppIcon name="close" :size="15" /></button></div></Transition>
</template>
